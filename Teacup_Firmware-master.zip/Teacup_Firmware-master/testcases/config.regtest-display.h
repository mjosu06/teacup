
// Configuration for controller board.
#include "../config/board.gen7-v1.1-v1.3.h"

// Configuration for printer board.
#include "../config/printer.wolfstrap.h"
