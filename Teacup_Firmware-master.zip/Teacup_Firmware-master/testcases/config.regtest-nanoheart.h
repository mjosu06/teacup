
// Configuration for controller board.
#include "../config/board.nanoheart-v1.0.h"

// Configuration for printer board.
#include "../config/printer.mendel.h"
