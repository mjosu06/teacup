
// Configuration for controller board.
#include "board.regtest-no-endstops.h"

// Configuration for printer
#include "../config/printer.wolfstrap.h"
