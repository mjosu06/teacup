
// Configuration for controller board.
#include "../config/board.cnc-shield-v3-nucleo.h"

// Configuration for printer board.
#include "../config/printer.wolfstrap.h"
