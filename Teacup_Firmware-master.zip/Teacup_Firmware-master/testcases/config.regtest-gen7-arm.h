
// Configuration for controller board.
#include "../config/board.gen7-arm.h"

// Configuration for printer board.
#include "../config/printer.wolfstrap.h"
