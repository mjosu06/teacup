
// Configuration for controller board.
#include "../config/board.gen7-v1.4.h"

// Configuration for printer board.
#include "../config/printer.wolfstrap.h"
#undef LOOKAHEAD
