
// Configuration for controller board.
#include "../config/board.gen3.h"

// Configuration for printer board.
#include "../config/printer.wolfstrap.h"
