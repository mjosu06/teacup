
/** \file
  \brief Delay routines, ARM specific part.
*/

#if defined TEACUP_C_INCLUDE && defined __ARM_STM32__


#endif /* defined TEACUP_C_INCLUDE && defined __ARM_STM32__ */
