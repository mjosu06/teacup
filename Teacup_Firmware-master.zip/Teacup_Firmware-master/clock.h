#ifndef	_CLOCK_H
#define	_CLOCK_H


// Should be called every TICK_TIME (currently 2 ms).
void clock_tick(void);

void clock(void);

#endif	/* _CLOCK_H */
