
/** \file
  \brief Simulated SPI subsystem
*/
#include "spi.h"
#include "arduino.h"

#ifdef SPI

void spi_init() {
}

#endif /* SPI */
