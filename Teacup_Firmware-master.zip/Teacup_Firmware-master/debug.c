#include	"debug.h"

volatile uint8_t	debug_flags;
